<?php

if (!isset($usuario)) {     

?>

    <a href="<?php echo BASE_URL; ?>/login" class="btn btn-dark position-relative float-end p-4 m-2">
        Login

    </a>

<?php
} else {
?>

    <a href="<?php echo BASE_URL; ?>/logout" class="btn btn-dark position-relative float-end p-4 m-2">

        Logout <?= $usuario->nombre; ?>

    </a>

<?php
}
?>