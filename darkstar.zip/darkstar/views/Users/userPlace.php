
<h2 class="text-white ">Mis compras:</h2>

<div class="">
        <table class="table table-dark table-striped" id="myTable">
            <thead>
                <tr>
                    
                    <th>orden nro:</th>
                    <th>id producto</th>
                    <th>Cliente -Nombre:</th>
                    <th>Cliente -Apellido:</th>
                    <th>Direccion:</th>
                    <th>Localidad:</th>
                    <th>Codigo postal</th>
                    <th>Telefono</th> 
                    <th>Cantidad comprada:</th>
                    <th>Monto total:</th>
                    <th>Estado:</th>
                    <th>Fecha:</th>
                </tr>
            </thead>

            <tbody class="text-white">
                <?php
                foreach ($ordenesDB as $item=>$orden) {
                ?>
                    <tr> 
                        <td><?php echo $orden->id; ?></td>
                        <td><?php echo $orden->id_producto; ?></td>
                        <td><?php echo $orden->nombre; ?></td>
                        <td><?php echo $orden->apellido; ?></td>
                        <td><?php echo $orden->direccion; ?></td>
                        <td><?php echo $orden->localidad; ?></td>    
                        <td><?php echo $orden->codigo_postal; ?></td>   
                        <td><?php echo $orden->telefono; ?></td>      
                        <td><?php echo $orden->cantidad; ?></td>
                        <td><?php echo $orden->monto; ?></td>
                        <td><?php echo $orden->estado; ?></td>
                        <td><?php echo $orden->fecha; ?></td> 
                   
                        <td>
                                             
                           </td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
         

        </table> 
        <div  class="d-flex p-2 m-2 " >
                <div class="boxes">                   
                </div> 
                <div><?php  (new \controllers\UsersController)->boton();?>
                <button class="btn p-1 m-1 "> <a class="btn btn-dark position-relative float-end p-4 m-2" href="<?php echo BASE_URL; ?>/Users/editarUser">Cambiar contraseña</a></button>
                </div>
                <button class="btn p-1 m-1"> <a class="btn btn-dark position-relative float-end p-4 m-2" href="<?php echo BASE_URL; ?>/Users/mostrarDatos">ver datos registrados</a></button>
                </div>
            </div>