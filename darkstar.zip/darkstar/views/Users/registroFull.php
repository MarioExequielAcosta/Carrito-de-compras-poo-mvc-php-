 


 <div class="container py-4 text-white h2">

     <form action="<?=BASE_URL?>/Users/editarRegistro" method="POST" enctype="multipart/form-data">

         <div class="form-group py-2">
             <label for="direccion">direccion :</label>
             <input type="text" name="direccion" class="form-control" id="nombre" placeholder="direccion" required value="<?php echo $usuario->direccion; ?>">
         </div>
         <div class="form-group py-2">
             <label for="localidad">localidad :</label>
             <input type="text" name="localidad" class="form-control" id="nombre" placeholder="localidad" value="<?php echo $usuario->localidad; ?>">
         </div>
         <div class="form-group py-2">
             <label for="codigo postal">codigo postal :</label>
             <input type="num" name="codigo_postal" class="form-control" id="email" placeholder="codigo postal" value="<?php echo $usuario->codigo_postal; ?>">
         </div>
         <div class="form-group py-2">
             <label for="telefono">telefono :</label>
             <input type="num" name="telefono" class="form-control" id="password" placeholder="telefono" value="<?php echo $usuario->telefono; ?>">
         </div>
        
 
        <div>
            <label for="tarjeta">tarjeta : </label>
        <select class="form-select form-select-sm" aria-label=".form-select-sm example" name="nombre_tarjeta">
             
        <option selected>opciones:</option>
            <option name="nombre_tarjeta" value="VISA">VISA</option>
            <option name="nombre_tarjeta" value="MASTERCARD">MASTERCARD</option>
            <option name="nombre_tarjeta" value="AMERICAN EXPRESS">AMERICAN EXPRESS</option>
    </select>
    </div>    
       
         <div class="form-group py-2">
             <label for="numero de tarjeta">numero de tarjeta : </label>
             <input type="text" name="tarjeta_numero" class="form-control" id="tarjeta" placeholder="numero de tarjeta " required>
         </div>
         
     

         <div class="py-2">
             <button type="submit" class="btn btn-primary">Guardar</button>
         </div>

     </form>

 </div>
</body>

</html>