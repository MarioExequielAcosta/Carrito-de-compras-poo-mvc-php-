<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   
    <title>Estadistica sobre productos</title>
</head>
<body >


    <div class="p-4 text-white bg-secondary">
        <div class="container d-flex">
            <h1>Resultados</h1>
        </div>
    </div>
    <div class=" py-4 text-white h2">

<table class="table text-white" id="myTable">
<div class="text-white h2">
              <?php
              $productosSinStock=0;
              $productosConStock=0;
              foreach($productos as $producto){
       if($producto->stock<=0){
        $productosSinStock+=1;
       }elseif($producto->stock>0){
        $productosConStock+=1;
       }

    }
?>
                <h3>Cantidad de productos sin stock = <?php if(isset($productosSinStock)) echo $productosSinStock; ?> </h3>
                <h3>Cantidad de productos con stock = <?php if(isset($productosConStock)) echo $productosConStock; ?> </h3>
          </div>

  
</table>

</div>

    
</body>

</html>