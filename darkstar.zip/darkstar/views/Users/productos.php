<h2 class="text-white ">Administracion de productos</h2>

<div class="">
        <table class= "table text-white h2" id="myTable">
            <thead>
                <tr>
                    
                    <th>producto</th>
                    <th>imagen</th>
                    <th>nombre</th>
                    <th>descripcion</th>
                    <th>precio</th>
                    <th>cantidad disponible</th>
                  
                 
                   
                    
                </tr>
            </thead>

            <tbody class="text-white">
           
                <?php
                foreach ($productos as $item => $producto) {
                    

                  
                ?>
                    <tr>
                        
                        <td><?php echo $producto->id; ?></td>
                        <td><img src="<?php echo BASE_URL?>/public/uploads/<?php echo $producto->imagen; ?>" width="40%"></td>
                        <td><?php echo $producto->nombre; ?></td>
                        <td><?php echo $producto->descripcion; ?></td>
                        <td><?php echo $producto->precio; ?></td>
                        <td><?php echo $producto->stock; ?></td>
                                         
                       
                      

                        <td>
                        <div   >
                            <a  href="<?php echo BASE_URL?>/admin/productos/eliminar/<?php echo $producto->id; ?>"  class="btn btn-danger"   >Eliminar</a>
                         
                            <a href="<?php echo BASE_URL?>/admin/productos/editar/<?php echo $producto->id ?>" class="btn btn-primary">Editar</a>
                            

                        </div>
                           
                        
                                                   
                           </td>
                    </tr>
                <?php
                }
               
                ?>
            
            </tbody>
            </div>
            <a href="<?php echo BASE_URL?>/admin/productos/agregar" class="btn btn-primary">Agregar nuevo producto</a>
        

        </table>
