<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   
    <title>Productos</title>
</head>
<body >


    <div class="p-4 text-white bg-secondary">
        <div class="container d-flex fs-6">
            <h1>Sus datos de registro:</h1>
        </div>
    </div>
    <div class=" py-4 text-white h2">

<table class="table table-dark" id="myTable">
    <thead>
        <tr>
            <th>nombre</th>
            <th>apellido</th>
            <th>email</th>
            <th>direccion</th>
            <th>localidad</th>
            <th>codigo postal</th>
            <th>telefono</th>
            <th>tarjeta</th>
            <th>numero de tarjeta</th>
        </tr>
    </thead>
	
            <tr>
                <td><?php echo $usuario->nombre; ?></td>
                <td><?php echo $usuario->apellido; ?></td>
                <td><?php echo $usuario->email; ?></td>
                <td><?php echo $usuario->direccion; ?></td>
                <td><?php echo $usuario->localidad; ?></td>
                <td><?php echo $usuario->codigo_postal; ?></td>
                <td><?php echo $usuario->telefono; ?></td>
                <td><?php echo $usuario->nombre_tarjeta; ?></td>
                <td><?php echo $usuario->tarjeta_numero; ?></td>
            </tr>
        <?php
        
        ?>

    </tbody>
</table>

</div>
<div>
<button class="btn"> <a class="btn btn-primary p-2 m-2" href="<?php echo BASE_URL; ?>/Users/editarRegistro">modificar registro</a></button>
                
</div>
    
</body>



</html>