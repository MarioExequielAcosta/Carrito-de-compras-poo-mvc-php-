<h2 class="text-white ">Administracion de Usuarios</h2>

<div class=" py-4 text-white h2">


<p>
    <a href="<?php echo BASE_URL?>/admin/users/agregar" class="btn btn-primary">Agregar</a>
</p>



<table class="table text-white" id="myTable">
    <thead>
        <tr>
            <th>id</th>
            <th>nombre</th>
            <th>email</th>
            
        </tr>
    </thead>

    <tbody>

        <?php
        foreach ($usuarios as $usuario) {
        ?>
            <tr>
                <td><?php echo $usuario->id; ?></td>
                <td><?php echo $usuario->nombre; ?></td>
                <td><?php echo $usuario->email; ?></td>
                <td>
                <a href="<?php echo BASE_URL?>/admin/users/eliminar/<?php echo $usuario->id; ?>" class="btn btn-danger">Eliminar</a>
              
              
            </tr>
        <?php
        }
        ?>

    </tbody>
</table>

</div>

        </table>