<h2 class="text-white ">Carrito de compras:</h2>

<div class="">
        <table class= "table text-white h2" id="myTable">
            <thead>
                <tr>
                    
                    <th>producto</th>
                    <th>imagen</th>
                    <th>nombre</th>
                    <th>descripcion</th>
                    <th>precio</th>
                    <th>cantidad disponible</th>
                    <th>iVA</th>
                    <th>precio + IVA</th> 
                    <th>en carrito</th>
                    
                </tr>
            </thead>

            <tbody class="text-white">
           
                <?php
                foreach ($productos as $item => $producto) {
                    

                  
                ?>
                    <tr>
                        
                        <td><?php echo $producto->id; ?></td>
                        <td><img src="<?php echo BASE_URL?>/public/uploads/<?php echo $producto->imagen; ?>" width="40%"></td>
                        <td><?php echo $producto->nombre; ?></td>
                        <td><?php echo $producto->descripcion; ?></td>
                        <td><?php echo $producto->precio; ?></td>
                        <td><?php echo $producto->stock; ?></td>
                         <td><?php echo "21%"?> </td>                    
                        <td><?php echo $producto->precio*1.21;?></td> 
                        <td> <?php if(isset($producto->cantidad)){ echo $producto->cantidad;}?></td>

                        <td>
                        <div   >
                            <a  href="./carrito/eliminar/<?php echo $producto->id; ?>"  class="btn btn-danger"   >Eliminar</a>
                         
                            <a href="./carrito/editar/<?php echo $producto->id ?>" class="btn btn-primary">Editar</a>
                            

                        </div>
                           
                        
                                                   
                           </td>
                    </tr>
                <?php
                }
               
                ?>
            
            </tbody>
            </div>
            <h3><p class="text-white">Subtotal de la compra= <?php echo $subtotal; ?></p></h3>
            <h3><p class="text-white">total de impuestos(IVA)= <?php echo $impuestos; ?></p></h3>
            <h3><p class="text-white">Monto Total +impuestos = <?php echo $total; ?></p></h3>
           <?php if($total!=0){ ?>
            <a href="<?php echo BASE_URL?>/carrito/finalizarCompra/<?php echo $producto->id ?>" class="btn btn-primary">Comprar</a>
           <?php } ?>

        </table>


    