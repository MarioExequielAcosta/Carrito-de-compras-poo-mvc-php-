<h1 class="h1 text-white"><?php echo $titulo; ?></h1>



<?php
(new controllers\ProductosController)->grilla();
?>
</div>