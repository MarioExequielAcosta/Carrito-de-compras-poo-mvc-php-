<div class=" text-white d-flex p-5 m-2">
<form class="d-flex" method="POST"   action="<?php echo BASE_URL;?>/productos/search/">Ingrese su producto:
    <input type="text" name="search" class="form-control" aria-label="Sizing example input" >
    <button class="btn btn-primary" type="submit"  value="$search" >Buscar
</form>

</div>