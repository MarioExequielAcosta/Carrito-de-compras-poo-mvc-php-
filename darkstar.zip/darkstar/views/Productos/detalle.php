
<div class="row text-white">
    <div class="col-6">

    <img src="<?php echo BASE_URL?>/public/uploads/<?= $producto->imagen; ?>" class="card-img-top " width="10%" alt="...">
    </div>
   
    <div class="col-6">

    <h1><?php echo $producto->nombre; ?></h1>
<p><?php echo $producto->descripcion; ?></p>
<h2>$<?php echo $producto->precio; ?></h2>
<p>Stock disponible: <?php echo $producto->stock; ?></p>

<p><?php if(isset($estadoProducto)&&$estadoProducto!=null){ echo $estadoProducto;} ?></p>

<?php if(isset($estadoProducto)){ ?>
<form method="POST" action="<?php echo BASE_URL?>/carrito/agregar/<?php echo $producto->id ?>">
<?php if($producto->stock>0){ ?> 
<input type="number" name="prodCant"  min="1" max=<?php echo $producto->stock; ?> required>	
<input class="btn btn-primary" type="submit" name="submit" value="actualizar cantidad"  >       <?php  }?></form>

<?php  }else{ ?>
<form method="POST" action="<?php echo BASE_URL?>/carrito/agregar/<?php echo $producto->id ?>">
<input type="number" name="prodCant"  min="1" max=<?php echo $producto->stock; ?> required>	
<input class="btn btn-primary" type="submit" name="submit"  value="agregar al carrito" ></form>
<?php }?>

</div>


</div>
<div><a href="<?php echo BASE_URL?>" class="btn btn-primary">volver</a></div>


  
   

   

