
<head>
<h2 class="text-white">Finalizar Compra :</h2>
</head>

<body class="container">
<div>
      <div>
      <table class= "table table-dark" id="myTable">
            <thead>
               
            <tr>
                    
                    <th>producto</th>
                    <th>nombre</th>
                    <th>descripcion</th>
                    <th>precio</th>
                    <th>cantidad disponible</th>
                    <th>iVA</th>
                    <th>precio + IVA</th> 
                    <th>en carrito</th>
                    
                </tr>
                
            </thead>
           
            <tbody class="text-white">
           
                <?php
                foreach ($productos as $item => $producto) {
                ?>
                    <tr>
                    
                        <td><?php echo $producto->id; ?></td>
                        <td><?php echo $producto->nombre; ?></td>
                        <td><?php echo $producto->descripcion; ?></td>
                        <td><?php echo $producto->precio; ?></td>
                        <td><?php echo $producto->stock; ?></td>
                         <td><?php echo "21%"?> </td>                    
                        <td><?php echo $producto->precio*1.21;?></td> 
                        <td> <?php if(isset($producto->cantidad)){ echo $producto->cantidad;}?></td>
                        <td>
                        <div>
                        </div>                      
                           </td>
                    </tr>
                <?php
                }
               
                ?>
            
            </tbody>
      </div>     
            
</body>

              <footer>  
                   
              <div class="container py-4 text-white h2">
         
<form action="<?=BASE_URL?>User/ordenCompra/generarOrden" method="POST" enctype="multipart/form-data">


    <div class=" py-4 text-white h2">

<table class="table table-dark" id="myTable">
    <thead>
        <tr>
            <th>nombre</th>
            <th>apellido</th>
            <th>email</th>
            <th>direccion</th>
            <th>localidad</th>
            <th>codigo postal</th>
            <th>telefono</th>
            <th>tarjeta</th>
            <th>numero de tarjeta</th>
        </tr>
    </thead>
	
            <tr>
                <td><?php echo $usuario->nombre; ?></td>
                <td><?php echo $usuario->apellido; ?></td>
                <td><?php echo $usuario->email; ?></td>
                <td><?php echo $usuario->direccion; ?></td>
                <td><?php echo $usuario->localidad; ?></td>
                <td><?php echo $usuario->codigo_postal; ?></td>
                <td><?php echo $usuario->telefono; ?></td>
                <td><?php echo $usuario->nombre_tarjeta; ?></td>
                <td><?php echo $usuario->tarjeta_numero; ?></td>
            </tr>
            <h4><p class="text-white">Subtotal de la compra= <?php echo $subtotal; ?></p></h4>
            <h4><p class="text-white">total de impuestos(IVA)= <?php echo $impuestos; ?></p></h4>
            <h4><p class="text-white">Monto Total +impuestos = <?php echo $total; ?></p></h4>
    </tbody>
</table>

</div>
<div>
<button class="btn"> <a class="btn btn-primary p-2 m-2" href="<?php echo BASE_URL; ?>/Users/editarRegistro">modificar registro</a></button>
                
</div>


</div>
            
                <div>
                <div>
           <h2 class="text-white">Verifique sus datos antes de finalizar la compra:</h2>
           </div>
                <a href="<?php echo BASE_URL?>/Users/ordenCompra/generarOrden"  class="btn btn-primary">finalizar Compra</a>
                </div>

    </footer> 


            </tbody>
    
        </table>


    