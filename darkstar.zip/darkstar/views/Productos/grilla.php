<div class="p-4 row row-cols-1 row-cols-sm-2 row-cols-md-4 g-4 ">
  
    <?php
  
foreach ($productos as $producto) {
    ?>
        <div class="container  p-2">
            <div class="card">
                <img src="public/uploads/<?= $producto->imagen; ?>"  class="card-img-top" width="100%"  alt="...">
                <div class="card-body">
                    <h5 class="card-title "><?php echo $producto->nombre; ?></h5>
                    <p class="card-text"><?php echo $producto->descripcion; ?></p>
                  
                    <a href="./productos/detalle/<?php echo $producto->id; ?>" class="stretched-link">$<?php echo $producto->precio; ?></a>
                </div>
            </div>

        </div>
    <?php
    }

    ?>

</div>
