<?php

namespace Models;
use core\Db;
class Usuario
{
	public $id;
	public $nombre;
	public $apellido;
	public $email;
	public $password;
	public $rol;
	public $direccion;
	public $localidad;
	public $codigo_postal;
	public $telefono;
	public $nombre_tarjeta;
	public $tarjeta_numero;

	function __construct($id,$nombre,$apellido,$email,$password,$rol,$direccion,$localidad,$codigo_postal,$telefono,$nombre_tarjeta,$tarjeta_numero)
	{
		$this->id=$id;
		$this->nombre=$nombre;
		$this->apellido=$apellido;
		$this->email=$email;
		$this->password=$password;
		$this->rol=$rol;
		$this->direccion=$direccion;
		$this->localidad=$localidad;
		$this->codigo_postal=$codigo_postal;
		$this->telefono=$telefono;
		$this->nombre_tarjeta=$nombre_tarjeta;
		$this->tarjeta_numero=$tarjeta_numero;
	}

	public static function getAll(){
		$listaUsuarios =[];
		$db=Db::getConnect(); 
		$stmt=$db->query('SELECT * FROM usuario ORDER BY id');

		foreach ($stmt->fetchAll() as $usuario) {
		$listaUsuarios[]= new Usuario($usuario['id'],$usuario['nombre'],$usuario['apellido'], $usuario['email'],$usuario['password'],$usuario['rol'],$usuario['direccion'],$usuario['localidad'],$usuario['codigo_postal'],$usuario['telefono'],$usuario['nombre_tarjeta'],$usuario['tarjeta_numero']);
		}

		return $listaUsuarios; 
	}

	public static function save($usuario){

			var_dump($usuario);

			$db=Db::getConnect();
			$insert=$db->prepare('INSERT INTO usuario VALUES(:id,:nombre,:apellido,:email,:password,:rol,:direccion,:localidad,:codigo_postal,:telefono,:nombre_tarjeta,:tarjeta_numero)');
			$insert->execute((array) $usuario); // supone que los atributos coinciden con los campos
		}


	public static function update($usuario){
		$db=Db::getConnect();
		$update=$db->prepare('UPDATE usuario SET nombre=:nombre, apellido=:apellido,email=:email, password=:password, rol=:rol ,direccion=:direccion, localidad=:localidad, codigo_postal=:codigo_postal, telefono=:telefono , nombre_tarjeta=:nombre_tarjeta , tarjeta_numero=:tarjeta_numero WHERE id=:id');
		$update->bindValue('id',$usuario->id);
		$update->bindValue('nombre',$usuario->nombre);
		$update->bindValue('apellido',$usuario->apellido);
		$update->bindValue('email',$usuario->email);
		$update->bindValue('password',$usuario->password);
		$update->bindValue('rol',$usuario->rol);
		$update->bindValue('direccion',$usuario->direccion);
		$update->bindValue('localidad',$usuario->localidad);
		$update->bindValue('codigo_postal',$usuario->codigo_postal);
		$update->bindValue('telefono',$usuario->telefono);
		$update->bindValue('nombre_tarjeta',$usuario->nombre_tarjeta);
		$update->bindValue('tarjeta_numero',$usuario->tarjeta_numero);
		$update->execute();
	}

	public static function delete($id){
		$db=Db::getConnect();
		$delete=$db->prepare('DELETE FROM usuario WHERE ID=:id');
		$delete->bindValue('id',$id);
		$delete->execute();
	}


	public static function getById($id){
		$db=Db::getConnect();
		$select=$db->prepare('SELECT * FROM usuario WHERE ID=:id');
		$select->bindValue('id',$id);
		$select->execute();
		
		$usuarioDb=$select->fetch();
		$usuario = new Usuario($usuarioDb['id'],$usuarioDb['nombre'],$usuarioDb['apellido'],$usuarioDb['email'],$usuarioDb['password'],$usuarioDb['rol'],$usuarioDb['direccion'],$usuarioDb['localidad'],$usuarioDb['codigo_postal'],$usuarioDb['telefono'],$usuarioDb['nombre_tarjeta'],$usuarioDb['tarjeta_numero']);
		return $usuario;
	}


	public static function login($email,$password){

		$db=Db::getConnect();
		$select=$db->prepare('SELECT * FROM usuario WHERE email=:email');
		$select->bindValue('email',$email);
		$select->execute();
		
		$usuarioDb=$select->fetch();


		if (password_verify($password, $usuarioDb['password'])){
			$usuario = new Usuario($usuarioDb['id'],$usuarioDb['nombre'],$usuarioDb['apellido'],$usuarioDb['email'],$usuarioDb['password'],$usuarioDb['rol'],$usuarioDb['direccion'],$usuarioDb['localidad'],$usuarioDb['codigo_postal'],$usuarioDb['telefono'],$usuarioDb['nombre_tarjeta'],$usuarioDb['tarjeta_numero	']);
			return $usuario;
		}else{
			return null;
		}

	}

}
