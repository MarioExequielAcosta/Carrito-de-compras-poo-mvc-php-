<?php

namespace Models;
use core\Auth;

class Carrito
{

	public static $productos = [];
		
	public static function save(ItemCompra $item){
		
		$usuario=Auth::getUser();
		if(!isset($_SESSION))
           session_start();
		if(isset($_SESSION['Carrito'][$usuario->id]))
        	Carrito::$productos = $_SESSION['Carrito'][$usuario->id];
		if(isset(Carrito::$productos[$item->producto->id]))		
			Carrito::$productos[$item->producto->id]->cantidad=$item->cantidad;
			else
			Carrito::$productos[$item->producto->id]=$item->producto;
			Carrito::$productos[$item->producto->id]->cantidad=$item->cantidad;
		$_SESSION['Carrito'][$usuario->id] = Carrito::$productos;
		
		
	}

	public static function delete($id){
		$usuario=Auth::getUser();
		if(!isset($_SESSION))
           session_start();
		if(isset($_SESSION['Carrito'][$usuario->id]))
        	Carrito::$productos = $_SESSION['Carrito'][$usuario->id];
			unset(Carrito::$productos[$id]);
			$_SESSION['Carrito'][$usuario->id] = Carrito::$productos;
    }


    public static function getProductos(){
		$usuario=Auth::getUser();
		if(isset($usuario)){
		if(!isset($_SESSION))
           session_start();
		}else {
			return Carrito::$productos;
		}
		   if(isset($_SESSION['Carrito'][$usuario->id]))
			Carrito::$productos = $_SESSION['Carrito'][$usuario->id];
		     return Carrito::$productos;
		  
		
	}
	public static function getById($id){
		if(!isset($_SESSION))
           session_start();
    	   if(isset($_SESSION['Carrito'][$id]))
			Carrito::$productos = $_SESSION['Carrito'][$id];
			return Carrito::$productos;
		}

	public static function getTotal(){
        $total = 0;
        foreach(Carrito::$productos as $item =>$producto){
            $total=$producto->precio*$producto->cantidad;
        }
        return $total;
    }

}
