<?php
namespace Models;
use core\Db;


class Producto
{
	public $id;
	public $nombre;
	public $descripcion;
	public $precio;
	public $stock;
	public $imagen;

	function __construct($id, $nombre, $descripcion, $precio, $stock, $imagen)
	{
		$this->id=$id;
		$this->nombre=$nombre;
		$this->descripcion=$descripcion;
		$this->precio=$precio;
		$this->stock=$stock;
		$this->imagen=$imagen;	
	}
	public static function getAll(){
		$listaProductos =[];
		$db=Db::getConnect(); 
		$stmt=$db->query('SELECT * FROM Producto ORDER BY id');

		foreach ($stmt->fetchAll() as $producto) {
			$listaProductos[]= new Producto($producto['id'],$producto['nombre'], $producto['descripcion'],$producto['precio'],$producto['stock'],$producto['imagen']);
		}

		 while($Producto = $stmt->fetch(\PDO::FETCH_OBJ)){
		 	$listaProductos[]= $Producto;
		 }
		return $listaProductos; 
	}
	public static function save($producto ){
			$db=Db::getConnect();
			$insert=$db->prepare(query:'INSERT INTO Producto (nombre, descripcion, precio) VALUES(:nombre,:descripcion, :precio)');
			$insert=$db->prepare(query:'INSERT INTO producto VALUES(:id,:nombre,:descripcion,:precio,:stock,:imagen)');
			// $insert->bindValue('nombre',$Producto->nombre);
			// $insert->bindValue('descripcion',$Producto->descripcion);
			// $insert->bindValue('precio',$Producto->precio);
			$insert->execute((array) $producto); // supone que los atributos coinciden con los campos
		}
	public static function update($producto){
		$db=Db::getConnect();
		$update=$db->prepare(query:'UPDATE producto SET nombre=:nombre, descripcion=:descripcion, precio=:precio, stock=:stock, imagen=:imagen WHERE id=:id');
		$update->bindValue('id',$producto->id);
		$update->bindValue('nombre',$producto->nombre);
		$update->bindValue('descripcion',$producto->descripcion);
		$update->bindValue('precio',$producto->precio);
		$update->bindValue('stock',$producto->stock);
		$update->bindValue('imagen',$producto->imagen);
		$update->execute();
	}
	public static function delete($id){
		$db=Db::getConnect();
		$delete=$db->prepare(query:'DELETE FROM producto WHERE ID=:id');
		$delete->bindValue('id',$id);
		$delete->execute();
	}
	public static function getById($id){
		$db=Db::getConnect();
		$select=$db->prepare(query:'SELECT * FROM producto WHERE ID=:id');
		$select->bindValue('id',$id);
		$select->execute();
		
		$productoDb=$select->fetch();
		$producto= new producto($productoDb['id'],$productoDb['nombre'],$productoDb['descripcion'],$productoDb['precio'],$productoDb['stock'],$productoDb['imagen']);
		return $producto;
	}
	public static function getByName($nombre){
	
		$db=Db::getConnect();
        $select=$db->prepare(query:'SELECT * FROM producto WHERE nombre LIKE :n ');
        $select->bindValue(':n',"%$nombre%",\PDO::PARAM_STR);
        $select->execute();
		
		foreach ($select->fetchAll() as $producto) {
            $listaProductos[]= new Producto($producto['id'],$producto['nombre'], $producto['descripcion'],$producto['precio'],$producto['stock'],$producto['imagen']);
         }
        if(isset($producto)){
        return $listaProductos; 
		}else{ return null;}

		}
	
}
	
	
			

