<?php

namespace Models;

class ItemCompra  {
    
    
    public $item=[];
	
    function __construct($producto,$cantidad){
      
        $this->producto=$producto;
		$this->cantidad=$cantidad;
    
}

// public $id_ordenCompra;
// public $id_producto;
// public $cantidad;

// public function _construct($id_ordenCompra, $id_producto, $cantidad){

//     $this->id_ordenCompra = $id_ordenCompra;
//     $this->id_producto = $id_producto;
//     $this->cantidad = $cantidad;

// }

// public static function getAll(){
//     $items=[];
//     $db=\Db::getConnect(); 
//     $stmt=$db->query('SELECT * FROM Items ORDER BY id');

//     foreach ($stmt->fetchAll() as $item) {
//         $itemsCompra[]= new ItemCompra($item['id_ordencompra'],$item['id_producto'], $item['cantidad']);
//     }

//      while($ItemCompra = $stmt->fetch(\PDO::FETCH_OBJ)){
//          $itemsCompra[]= $ItemCompra;
//      }
//     return $items; 
// }
// public static function save($item){
//         $db=\Db::getConnect();
//         $insert=$db->prepare(query:'INSERT INTO Items (id_ordenCompra, id_producto, cantidad) VALUES(:id_ordenCompra,:id_producto, :cantidad)');
//         $insert=$db->prepare(query:'INSERT INTO items VALUES(:id_ordenCompra,:id_producto,:cantidad)');
//         // $insert->bindValue('nombre',$Producto->nombre);
//         // $insert->bindValue('descripcion',$Producto->descripcion);
//         // $insert->bindValue('precio',$Producto->precio);
//         $insert->execute((array) $item); // supone que los atributos coinciden con los campos
//     }
// public static function update($item){
//     $db=\Db::getConnect();
//     $update=$db->prepare(query:'UPDATE item SET id_ordenCompra=:id_ordenCompra, id_producto=:id_producto, cantidad=:cantidad WHERE id=:id');
//     $update->bindValue('id_ordenCompra',$item->id_ordenCompra);
//     $update->bindValue('id_producto',$item->id_producto);
//     $update->bindValue('cantidad',$item->cantidad);
//     $update->execute();
// }
// public static function delete($id){
//     $db=\Db::getConnect();
//     $delete=$db->prepare(query:'DELETE FROM items WHERE ID=:id');
//     $delete->bindValue('id',$id);
//     $delete->execute();
// }
// public static function getById($id){
//     $db=\Db::getConnect();
//     $select=$db->prepare(query:'SELECT * FROM items WHERE ID=:id');
//     $select->bindValue('id',$id);
//     $select->execute();
    
//     $itemDb=$select->fetch();
//     $itemsCompra[]= new ItemCompra($itemDb['id_ordencompra'],$itemDb['id_producto'], $itemDb['cantidad']);
//     return $itemsCompra;
// }
// public static function getByName($nombre){

//     $db=\Db::getConnect();
//     $select=$db->prepare(query:'SELECT * FROM items WHERE nombre LIKE :n ');
//     $select->bindValue(':n',"%$nombre%",\PDO::PARAM_STR);
//     $select->execute();
    
//     foreach ($select->fetchAll() as $item) {
//         $itemsCompra[]= new ItemCompra($item['id_ordencompra'],$item['id_producto'], $item['cantidad']);
//      }
//     if(isset($item)){
//     return $itemsCompra; 
//     }else{ return null;}

//     }




}
   
    
     







