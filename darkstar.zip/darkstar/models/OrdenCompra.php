<?php
namespace Models;
use core\Db;


class OrdenCompra
{
	public $id;
	public $id_producto;
	public $id_usuario;
	public $nombre;
	public $apellido;
	public $direccion;
	public $localidad;
	public $codigo_postal;
    public $telefono;
	public $cantidad;
	public $monto;
	public $estado;
	public $fecha;
    
	function __construct($id,$id_producto,$id_usuario,$nombre,$apellido,$direccion,$localidad,$codigo_postal,$telefono,$cantidad,$monto,$estado,$fecha)
	{
		$this->id=$id;
		$this->id_producto=$id_producto;
		$this->id_usuario=$id_usuario;
		$this->nombre=$nombre;
		$this->apellido=$apellido;
		$this->direccion=$direccion;
		$this->localidad=$localidad;
		$this->codigo_postal=$codigo_postal;
        $this->telefono=$telefono;
		$this->cantidad=$cantidad;
		$this->monto=$monto;
		$this->estado=$estado;
		$this->fecha=$fecha;
	}
	public static function getAll(){
		$OrdenesDeCompra =[];
		$db=Db::getConnect(); 
		$stmt=$db->query('SELECT * FROM orden ORDER BY id');


		foreach ($stmt->fetchAll() as $orden) {
			$OrdenesDeCompra[]= new OrdenCompra($orden['id'],$orden['id_producto'],$orden['id_usuario'],$orden['nombre'], $orden['apellido'],$orden['direccion'],$orden['localidad'],$orden['codigo_postal'],$orden['telefono'],$orden['cantidad'],$orden['monto'],$orden['estado'],$orden['fecha']);
		}

		 while($OrdenCompra = $stmt->fetch(\PDO::FETCH_OBJ)){
		 	$OrdenesDeCompra[]= $OrdenCompra;
		 }
		return $OrdenesDeCompra; 
	}
	public static function save($orden){
			$db=Db::getConnect();
			$insert=$db->prepare(query:'INSERT INTO orden (id,id_producto,id_usuario,nombre,apellido,direccion,localidad,codigo_postal,telefono,cantidad,monto,estado,fecha) VALUES(:id,:id_producto,:id_usuario,:nombre,:apellido,:direccion,:localidad,:codigo_postal,:telefono,:cantidad,:monto,:estado,:fecha)');
		//	$insert=$db->prepare(query:'INSERT INTO orden VALUES(:id_producto,:id_usuario,:nombre,:apellido,:direccion,:localidad,:codigo_postal,:telefono,:cantidad,:estado)');
			// $insert->bindValue('nombre',$Producto->nombre);
			// $insert->bindValue('descripcion',$Producto->descripcion);
			// $insert->bindValue('precio',$Producto->precio);
			$insert->execute((array) $orden); // supone que los atributos coinciden con los campos
		}
	public static function update($orden){
		$db=Db::getConnect();
		$update=$db->prepare(query:'UPDATE orden SET id_producto=:id_producto,id_usuario=:id_usuario,nombre=:nombre, apellido=:apellido, direccion=:direccion, localidad=:localidad, codigo_postal=:codigo_postal, telefono=:telefono,cantidad=:cantidad,monto=:monto,estado=:estado,fecha=:fecha WHERE id=:id');
		$update->bindValue('id',$orden->id);
		$update->bindValue('id_producto',$orden->id_producto);
		$update->bindValue('id_usuario',$orden->id_usuario);
		$update->bindValue('nombre',$orden->nombre);
		$update->bindValue('apellido',$orden->apellido);
		$update->bindValue('direccion',$orden->direccion);
		$update->bindValue('localidad',$orden->localidad);
		$update->bindValue('codigo_postal',$orden->codigo_postal);
		$update->bindValue('telefono',$orden->telefono);
		$update->bindValue('cantidad',$orden->cantidad);
		$update->bindValue('monto',$orden->monto);
		$update->bindValue('estado',$orden->estado);
		$update->bindValue('fecha',$orden->fecha);
		$update->execute();
	}

	public static function delete($id){
		$db=Db::getConnect();
		$delete=$db->prepare(query:'DELETE FROM orden WHERE ID=:id');
		$delete->bindValue('id',$id);
		$delete->execute();
	}
	public static function getById($id){
		$ordenes =[];
		$db=Db::getConnect();
		$select=$db->prepare(query:'SELECT * FROM orden WHERE id_usuario=:id_usuario');
		$select->bindValue('id_usuario',$id);
		$select->execute();
		
		foreach ($select->fetchAll() as $orden) {
			$ordenes[]= new OrdenCompra($orden['id'],$orden['id_producto'],$orden['id_usuario'],$orden['nombre'], $orden['apellido'],$orden['direccion'],$orden['localidad'],$orden['codigo_postal'],$orden['telefono'],$orden['cantidad'],$orden['monto'],$orden['estado'],$orden['fecha']);
		}

		 while($OrdenCompra = $select->fetch(\PDO::FETCH_OBJ)){
		 	$ordenes[]= $OrdenCompra;
		 }
		return $ordenes; 
	
	}
	public static function getByName($nombre){
	
		$db=Db::getConnect();
        $select=$db->prepare(query:'SELECT * FROM orden WHERE nombre LIKE :n ');
        $select->bindValue(':n',"%$nombre%",\PDO::PARAM_STR);
        $select->execute();
		
		foreach ($select->fetchAll() as $orden) {
            $OrdenesDeCompra[]= new OrdenCompra($orden['id'],$orden['id_producto'],$orden['id_usuario'],$orden['nombre'], $orden['apellido'],$orden['direccion'],$orden['localidad'],$orden['codigo_postal'],$orden['telefono'],$orden['cantidad'],$orden['monto'],$orden['estado'],$orden['fecha']);
         }
        if(isset($orden)){
        return $OrdenesDeCompra; 
		}else{ return null;}

		}
	
}
	
	