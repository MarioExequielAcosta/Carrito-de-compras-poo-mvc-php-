<?php

namespace controllers;
use core\Auth;
use core\Render;
use models\Producto;
use models\Carrito;
use Views\Layout;
use FFI\Exception;

class HomeController{

    public function index(){
    
      try{ 
        $titulo = "Nuestros Productos";
        $context['productos'] = Producto::getAll();  
        $usuario=Auth::getUser();
  
       
        if(isset($usuario)){
                 if($usuario->rol=='User'){
              Render::html('views\layoutUser','/home/index',[$context,'titulo'=>$titulo]);
               }else if($usuario->rol=='Admin'){
                 Render::html('Views\LayoutAdmin','/home/index',[$context,'titulo'=>$titulo]);
               }
         }else{ 
              Render::html('Views\Layout','/home/index',[$context,'titulo'=>$titulo]);
            }

    }
   catch (Exception $e) {
    echo 'Error No se puede mostrar!'; $e->getMessage();
    die();
}

  }

}
?>