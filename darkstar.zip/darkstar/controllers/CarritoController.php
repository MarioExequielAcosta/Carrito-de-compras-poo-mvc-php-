<?php
namespace controllers;
require_once("config.php");
use FFI\Exception;
use core\Render;
use models\Carrito;
use models\Producto;
use Models\ItemCompra;
use Models\Usuario;
use Models\OrdenCompra;
use controllers\ordenController;
use core\Auth;

class CarritoController{
    
    public function index(){
       $subtotal=0;
       $impuestos=0;
       $usuario=Auth::getUser();
      try{
       if(isset($usuario)){
       $productos = Carrito::getProductos();
       } 
       if(isset($productos)&&$productos!=null){
       foreach($productos as $producto) {
        $subtotal+=$producto->precio*$producto->cantidad;
        $impuestos+=$producto->precio*IVA*$producto->cantidad;
       
      }
    }
      $total=$subtotal+$impuestos;
      
      if(isset($usuario)){
      if($usuario->rol=='User'){
        Render::html('views\layoutUser','Carrito/index',['productos'=>$productos,'subtotal'=>$subtotal,'impuestos'=>$impuestos,'total'=>$total]);
      } 
    }else{
        Render::html('views\layout','Carrito/index',['productos'=>$productos,'subtotal'=>$subtotal,'impuestos'=>$impuestos,'total'=>$total]);
       }    
      } catch (Exception $e) {
        echo $e->getMessage();
        die();
    }
    
      }
    
    public function agregar($id){
       
try{
    
        if(isset($_POST)){
         
            if(isset($_POST['prodCant']))
            $cantidad=$_POST['prodCant'];
            $producto = Producto::getById($id);
             
           $item=new ItemCompra($producto,$cantidad);
          
            Carrito::save($item);
           
           $producto->stock-=$cantidad;  
          
        header("Location: " . BASE_DIR. "carrito");
   
        }
      } catch (Exception $e) {
        echo 'Error intentelo mas tarde!'; $e->getMessage();
        die();
    }
      }

    public function eliminar($id){
      try{
      
         $usuario=Auth::getUser();
       if(isset($_GET[$id])){
        $producto=Producto::getById($id);
        $carrito=Carrito::getById($usuario->id);
      $producto->stock+=$carrito[$id]->cantidad;
       }
        Carrito::delete($id);
        header("Location: " . BASE_DIR. "carrito");
      

      } catch (Exception $e) {
        echo 'Error al intentar eliminar'; $e->getMessage();
        die();
    }
    }
        
    public function editar($id){
        $usuario=Auth::getUser();
       
       try{
        if(isset($_POST)){
   
            if (isset($_POST['prodCant']))
   
            $cantidad=$_POST['prodCant'];
            
       $producto = Producto::getById($id);
       $itemCarrito=Carrito::getProductos();
       if(isset($itemCarrito[$id])){
      
        
        $estadoProducto= "Este producto ya esta en su carrito..";
  }
  if($usuario->rol=='User'){
  Render::html('views\layoutUser','productos/detalle',['producto'=>$producto,'estadoProducto'=>$estadoProducto]);
  }else{
    Render::html('views\layout','productos/detalle',['producto'=>$producto,'estadoProducto'=>$estadoProducto]);
  }                 
        }
      } catch (Exception $e) {
        echo 'Error al intentar Editar'; $e->getMessage();
        die();
    }   
    }       
    public function finalizarCompra(){
      $usuario=Auth::getUser();
      $usuarioBd=Usuario::getById($usuario->id);
     try{
      if($usuario->id==$usuarioBd->id){
          $usuario=$usuarioBd;
      }

        $subtotal=0;
        $impuestos=0;
        $productos=Carrito::getById($usuario->id);
      foreach($productos as $producto) {
        $subtotal+=$producto->precio*$producto->cantidad;
        $impuestos+=$producto->precio*IVA*$producto->cantidad;
       
        $producto->stock-$producto->cantidad;
        Producto::update($producto);
       }
      $total=$subtotal+$impuestos;
      if($usuario->rol=='User'){
      Render::html('views\layoutUser','Productos/finalizarCompra',['productos'=>$productos,'subtotal'=>$subtotal,'impuestos'=>$impuestos,'total'=>$total,'usuario'=>$usuario]);
      }else{
        Render::html('views\layout','Productos/finalizarCompra',['productos'=>$productos,'subtotal'=>$subtotal,'impuestos'=>$impuestos,'total'=>$total]);
      }

    } catch (Exception $e) {
      echo 'Error desconocido.' ;$e->getMessage();
      die();
  }
    }     
    
    public function boton(){
       
        $productos = count(Carrito::getProductos()); 
        require_once("./views/Carrito/boton.php");
    }
    
    public function pagar(){
      
      $productos=Carrito::getProductos();
        foreach($productos as $producto){
            $id=$producto->id;
           
            Carrito::delete($id);
            
        }
      
        header("Location: " . BASE_DIR. "carrito");

    }
}
