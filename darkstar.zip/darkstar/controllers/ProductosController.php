<?php

namespace controllers;
use FFI\Exception;
use core\Auth;
use models\Producto;
use models\Carrito;
use core\Render;

class ProductosController {

    public function index()    {

        try {
        $productos = Producto::getAll();
        $usuario=Auth::getUser();
    if($usuario->rol=='User'){
        Render::html('views\layoutUser','Productos/grilla',['productos'=>$productos]);
    }  else{
        Render::html('views\layout','Productos/grilla',['productos'=>$productos]);
    }
}
catch (Exception $e) {
    echo 'Error No se puede mostrar!'; $e->getMessage();
    die();

}    

}

    public function agregar(){
       
        try{
        if ($_POST) {
          
            $permitidos = array("image/jpeg", "image/png", "image/gif", "image/jpg");
            $limite = 700;
            if(in_array($_FILES['imagen']['type'], $permitidos) && $_FILES['imagen']['size'] <= $limite * 1024 * 3){
                $imagen = date('is') . $_FILES['imagen']['name'];
                $ruta = "public/uploads/". $imagen;
                if(!move_uploaded_file($_FILES['imagen']['tmp_name'], $ruta)){
                    die("No se pudo cargar el archivo");
                }
                $productos = new Producto(null, $_POST['nombre'], $_POST['descripcion'], $_POST['precio'], $_POST['stock'], $imagen );
                Producto::save($productos);
                header("Location: " . BASE_URL. "/admin/productos");
            }else{
                die("Archivo no permitido");
            }       
        }
         if($_GET){
            Render::html('views\layoutAdmin','/productos/agregar',[]);
        }  
    }
    catch (Exception $e) {
        echo 'Error No se puede realizar la operacion!'; $e->getMessage();
        die();
    
    }

    }

    public function eliminar($id)
    {
       try{
        if ($id) {
            
            Producto::delete($id);
        }
        header("Location: " . BASE_DIR. "admin/productos");
    }
    catch (Exception $e) {
        echo 'Error No se puede realizar la operacion!'; $e->getMessage();
        die();
    
    }
    }

    public function editar($id){

      try {
        $producto = Producto::getById($id);

      Render::html('views\layoutAdmin','productos/editar',['producto'=>$producto]);

    }
    catch (Exception $e) {
        echo 'Error No se puede realizar la operacion!'; $e->getMessage();
        die();
    
    }
        }
        public function guardar($id){
            $producto = Producto::getById($id);
            try {
            if (!$_POST) {
                Render::html('views\layoutAdmin','/admin/productos/editar',['producto'=>$producto]);
               
            } else {
                $producto = new Producto($_POST['id'], $_POST['nombre'], $_POST['descripcion'], $_POST['precio'], $_POST['stock'], $producto->imagen);
                Producto::update($producto);
               
              
             
              header("Location: " . BASE_URL. "/admin/productos");
            }
        }
        catch (Exception $e) {
            echo 'Error No se puede realizar la operacion!'; $e->getMessage();
            die();
        
        }
        }
    public function grilla(){
        $productos = Producto::getAll(); 
        require_once("views/productos/grilla.php");
    }


    public function detalle($id){
       try {
        $usuario=Auth::getUser();
        $producto = Producto::getById($id);
        $itemCarrito=Carrito::getProductos();
       try {
        if(isset($itemCarrito[$id])){
            $estadoProducto= "Este producto ya esta en su carrito..";
      }else{
        $estadoProducto=null;
      }
        if($producto->stock>0){
        
        if($estadoProducto!=null){
            
            if(isset($usuario) && $usuario->rol=='User'){
                Render::html('views\layoutUser','productos/detalle',['estadoProducto'=>$estadoProducto,'producto'=>$producto]);
            }else{
                Render::html('views\layout','productos/detalle',['estadoProducto'=>$estadoProducto,'producto'=>$producto]);
            }
        }else{
            if(isset($usuario->rol)&&$usuario!=null){
                Render::html('views\layoutUser','productos/detalle',['producto'=>$producto]);
            }else{
                Render::html('views\layout','productos/detalle',['producto'=>$producto]);
            }    
        }
       }else{
           $estadoProducto="Producto sin stock disponible.";
            Render::html('views\layout','productos/detalle',['producto'=>$producto,'estadoProducto'=>$estadoProducto]);
        }   
    }
    catch (Exception $e) {
        echo 'Error No se puede realizar la operacion!'; $e->getMessage();
        die();
    
    }
}
catch (Exception $e) {
    echo 'Error No se puede realizar la operacion!'; $e->getMessage();
    die();

}    
}
    public function buscador(){
        $search="";
          if(isset($_post)){
              $busqueda=$_post["search"];
          }
          require_once("views/Productos/buscador.php");
      }


    public function search(){
            try{
        $usuario=Auth::getUser();
        if(isset($_POST)){
            if(isset($_POST["search"])){            
            
                $nombre=$_POST["search"];
                  
              $productos=Producto::getByName($nombre);
           
              if($productos){
            $resultadoBusqueda= count($productos);
            if(count($productos)>1) 
                $resultadoBusqueda.=" resultados para la busqueda: ".$nombre;
                
             else 
                $resultadoBusqueda.=" resultado para la busqueda:".$nombre;
            
            }else{
                $productos=null;
                $resultadoBusqueda="no se encontraron resultados para la busqueda:".$nombre;
            } 
        }
    }
    
    if(!isset($usuario->rol)){
        Render::html('views\layout','productos/resultadoBusqueda',['productos'=>$productos,'resultadoBusqueda'=>$resultadoBusqueda]); 
       
    }else{
        Render::html('views\layoutUser','productos/resultadoBusqueda',['productos'=>$productos,'resultadoBusqueda'=>$resultadoBusqueda]);
    }
}
catch (Exception $e) {
    echo 'Error No se puede realizar la operacion!'; $e->getMessage();
    die();

}
    }

}
     

