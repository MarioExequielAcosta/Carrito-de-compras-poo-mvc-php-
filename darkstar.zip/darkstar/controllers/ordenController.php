<?php

namespace controllers;
use FFI\Exception;
use Models\Usuario;
use Models\Producto;
use core\Auth;
use core\Render;
use DateTime;
use Models\Carrito;
use Models\OrdenCompra;

class ordenController {



    public function generarOrden(){
        try{
        $usuarioSesion=Auth::getUser();
        $usuarioBd=Usuario::getById($usuarioSesion->id);
        if($usuarioSesion->id==$usuarioBd->id){
            $usuario=$usuarioBd;
        }  
        $productos=Carrito::getById($usuario->id);

        foreach($productos as $producto){
            $estado ="EN PROCESO";
            $monto =($producto->precio * $producto->cantidad)*1.21;
            $fecha = date('y-m-d');
            $orden = new OrdenCompra(null,$producto->id,$usuario->id,$usuario->nombre,$usuario->apellido,$usuario->direccion,$usuario->localidad,$usuario->codigo_postal,$usuario->telefono,$producto->cantidad,$monto,$estado,$fecha);
           OrdenCompra::save($orden);
           Carrito::delete($producto->id);
        }
            
            $ordenesDB=OrdenCompra::getById($usuario->id);
        
            if($usuario->rol=='User'){
                Render::html('views\layoutUser','Users/verOrdenesCompra',['ordenesDB'=>$ordenesDB]);
    
                }else{
                  Render::html('views\layout','index',[]);
                }  
            }
                catch (Exception $e) {
                    echo 'Error en la operacion!'; $e->getMessage();
                    die();
                
                }
            }
    public function adminOrdenCOmpra(){
       try {
        $usuarioSesion=Auth::getUser();
        $usuarioBd=Usuario::getById($usuarioSesion->id);
        if($usuarioSesion->id==$usuarioBd->id){
            $usuario=$usuarioBd;
        } 
         
        $ordenes=OrdenCompra::getAll();

            if($usuario->rol=='Admin'){
                Render::html('views\layoutAdmin','Users/verOrdenesCompraAdmin',['ordenesDB'=>$ordenes]);
    
                }else{
                  Render::html('views\layout','index',[]);
                }  

            }
            catch (Exception $e) {
                echo 'Error!'; $e->getMessage();
                die();
            
            }
    }
public function actualizarOrden($id){
      
    try {
    $ordenesDB=OrdenCompra::getAll();   
    $usuario=Auth::getUser();

    if(isset($_POST)){
        if(isset($_POST['formSelector'])){
           $varOrden=$_POST['formSelector'];
        }
    }
            foreach($ordenesDB as $orden ){
                    if($orden->id==$id){
                        $orden->estado=$varOrden;
                        $orden->fecha = date('y-m-d');
                         
                       }
                       OrdenCompra::update($orden);
        }
    if($usuario->rol=='Admin'){
      
        Render::html('views\layoutAdmin','Users/verOrdenesCompraAdmin',['ordenesDB'=>$ordenesDB]);

        }else{
          Render::html('views\layout','index',[]);
        } 
    }
    catch (Exception $e) {
        echo 'Error al actualizar!'; $e->getMessage();
        die();
    
    }
}
        
}