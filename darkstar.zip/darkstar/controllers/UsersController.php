<?php

namespace controllers;

use Models\Usuario;
use Models\Producto;
use core\Auth;
use core\Render;
use Models\Carrito;
use Models\OrdenCompra;

class UsersController {

    public function index(){
        $context['productos'] = Producto::getAll(); 
        $usuario=Usuario::getAll();
        $usuarioAuth=Auth::getUser();
        $titulo = "Nuestros Productos";
       if(isset($usuario)){
             if($usuarioAuth->rol=='Admin'){
                 Render::html('Views\LayoutAdmin','users/index',['usuario'=>$usuario]);
                 }else if($usuarioAuth->rol=='User'){
                  Render::html('Views\LayoutUser','/home/index',[$context,'titulo'=>$titulo]);
                 }
                }else{
            Render::html('Views\Layout','/home/index',[$context,'titulo'=>$titulo]);
        }
       
    }
   
    public function boton(){

      $usuario = Auth::getUser();

      require_once("./views/Users/boton.php");
  }
   


  public function login(){

    if (!$_POST) {

       // \Render::html('Views\LayoutAdmin','users/login',[]);
        require_once('./views/Users/login.php');

    }else{

        $email =$_POST['email'];
        $usuario = Usuario::login($_POST['email'], $_POST['password']);

       //var_dump($usuario);

        if(isset($usuario)){
            Auth::login($usuario);
            if($usuario->rol=='Admin'){
            header('Location: '.BASE_URL.'/admin/index');
          } else if($usuario->rol=='User'){
            header('Location: '.BASE_URL.'/index');
          } 
          
            
        }else{
            $usuario = Usuario::login($_POST['email'], $_POST['password']);
         
            header('Location: '.BASE_URL.'/login');
        }

    }

}

  public function logout(){

    Auth::logout();
    header('Location: '.BASE_URL.'/login');

} 
  
  
  public function productos(){
      
      $productos=Producto::getAll();
    
    
        Render::html('Views\LayoutAdmin','users/productos',['productos'=>$productos]);
      
    }
    public function usuarios(){

        $usuarios=Usuario::getAll();
          Render::html('Views\LayoutAdmin','users/usuarios',['usuarios'=>$usuarios]);
        
      }
      public function estadistica(){
       $productos=Producto::getAll();
          
        Render::html('Views\LayoutAdmin','users/estadisticas',['productos'=>$productos]); 
      }
   public function agregar()
   {

       if (!$_POST) {
            Render::html('Views\layoutAdmin', 'users/agregar', []);
         //  require_once('./views/Users/agregar.php');
       } else {

            $hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $rol='Admin';
             $usuario = new Usuario(null, $_POST['nombre'],$_POST['apellido'], $_POST['email'], $hash,$rol,null,null,null,null,null,null);
           Usuario::save($usuario);
           header("Location: " . BASE_URL . "/admin/index");
       }
   }
   public function agregarNuevoUsuario()
   {

       if (!$_POST) {
            Render::html('Views\layout', 'Users/nuevoUsuario', []);
      
       } else {

            $hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $rol='User';

           $usuario = new Usuario(null, $_POST['nombre'],$_POST['apellido'], $_POST['email'], $hash, $rol,null,null,null,null,null,null );
           Usuario::save($usuario);
           header("Location: " . BASE_URL . "/");
       }
   
    }

   public function userPlace()   {    
    $subtotal=0;
    $impuestos=0;
    $usuario=Auth::getUser();
     $productos = Carrito::getProductos();
     
    foreach($productos as $producto) {
     $subtotal+=$producto->precio*$producto->cantidad;
     $impuestos+=$producto->precio*IVA*$producto->cantidad;
    }
   $total=$subtotal+$impuestos;
    
        $productos = Carrito::getProductos();
        $ordenesDB= OrdenCompra::getById($usuario->id);
        Render::html('views\layoutUser','Users/userPlace',['productos'=>$productos,'subtotal'=>$subtotal,'impuestos'=>$impuestos,'total'=>$total,'ordenesDB'=>$ordenesDB]);
      
   }

    public function eliminar($id){
      
        if (isset($id)) {
         
            Usuario::delete($id);
           
        }
        header("Location: " . BASE_DIR. "admin/index");    
    }
     public function editar(){
       $usuario=Auth::getUser();
       
       if(!$_POST){  
           
                if($usuario->rol=='Admin'){
                    Render::html('Views\layoutAdmin', 'users/editarAdmin', ['usuario'=>$usuario]);
                }else{
                Render::html('Views\layoutUser', 'users/editarUser', ['usuario'=>$usuario]);
               }
           
        } else {
            $id=$usuario->id;
            $nombre=$usuario->nombre;
            $apellido=$usuario->apellido;
            $email=$usuario->email;
            $hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $rol=$usuario->rol;
            $usuario = new Usuario($id,$nombre,$apellido,$email,$hash,$rol,null,null,null,null,null,null);
          
            Usuario::update($usuario);
            header("Location: " . BASE_URL . "/");
     }
    }
     
    public function editarRegistro(){
        $usuario=Auth::getUser();

        if (!$_POST) {
            Render::html('Views\layout', 'Users/registroFull', ['usuario'=>$usuario]);
         //  require_once('./views/Users/agregar.php');
       } else {
            $id=$usuario->id;
            $nombre=$usuario->nombre;
            $apellido=$usuario->apellido;
            $email=$usuario->email;
            $hash = $usuario->password;  //password_hash($_POST['password'], PASSWORD_DEFAULT);
            $rol='User';

           $usuario = new Usuario($id,$nombre,$apellido,$email, $hash, $rol,$_POST['direccion'],$_POST['localidad'],$_POST['codigo_postal'],$_POST['telefono'],$_POST['nombre_tarjeta'],$_POST['tarjeta_numero'] );
           Usuario::update($usuario);
           header("Location: " . BASE_URL . "/");
       }
   
    }
        public function mostrarDatos(){
            $usuarioSesion=Auth::getUser();
            $usuarioBd=Usuario::getById($usuarioSesion->id);
            if($usuarioSesion->id==$usuarioBd->id){
                $usuario=$usuarioBd;
            }
            Render::html('Views\layoutUser', 'users/mostrarDatos', ['usuario'=>$usuario]);

        }


     }



