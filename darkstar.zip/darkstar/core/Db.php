<?php
namespace core;
class Db

{

    public static function getConnect()
    {
        try {
            $pdo_options[\PDO::ATTR_ERRMODE] = \PDO::ERRMODE_EXCEPTION;
            return new \PDO('mysql:host=localhost;dbname=test', 'root', '', $pdo_options);
        } catch (\PDOException $e) {
            print "¡Error CHequear Bd!: " . $e->getMessage() . "<br/>";
            die();
        }
    }
}
